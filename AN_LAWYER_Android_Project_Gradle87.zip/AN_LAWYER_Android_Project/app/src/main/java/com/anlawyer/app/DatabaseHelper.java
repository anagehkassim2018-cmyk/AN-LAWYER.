package com.anlawyer.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context c) { super(c, "an_lawyer.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE cases (_id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT, court TEXT, type TEXT, parties TEXT, next_date TEXT, notes TEXT)");
        db.execSQL("CREATE TABLE clients (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, address TEXT, notes TEXT)");
        db.execSQL("CREATE TABLE sessions (_id INTEGER PRIMARY KEY AUTOINCREMENT, case_number TEXT, court TEXT, date TEXT, decision TEXT)");
        db.execSQL("CREATE TABLE tasks (_id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, due_date TEXT, done INTEGER DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { }
    public long add(String table, ContentValues values) { return getWritableDatabase().insert(table, null, values); }
    public Cursor all(String table) { return getReadableDatabase().rawQuery("SELECT * FROM " + table + " ORDER BY _id DESC", null); }
    public int count(String table) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + table, null);
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }
}
