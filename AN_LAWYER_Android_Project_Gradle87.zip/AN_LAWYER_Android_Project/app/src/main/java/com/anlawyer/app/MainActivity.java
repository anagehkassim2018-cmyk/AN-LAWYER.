package com.anlawyer.app;

import android.app.*;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    final int navy = Color.rgb(16,28,53), gold = Color.rgb(207,174,103), cream = Color.rgb(248,247,243);
    DatabaseHelper db;
    LinearLayout root, body;
    String current = "cases";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); db = new DatabaseHelper(this); showHome();
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(14,12,14,12); return t;
    }
    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(cream);
        TextView head = text("AN LAWYER  |  " + title, 20, gold); head.setTypeface(null, Typeface.BOLD); head.setBackgroundColor(navy);
        root.addView(head); body = new LinearLayout(this); body.setOrientation(1); body.setPadding(12,8,12,8);
        ScrollView sc = new ScrollView(this); sc.addView(body); root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setBackgroundColor(navy);
        addNav(nav,"الرئيسية","home"); addNav(nav,"القضايا","cases"); addNav(nav,"الموكلون","clients"); addNav(nav,"الجلسات","sessions"); addNav(nav,"المهام","tasks");
        root.addView(nav); setContentView(root);
    }
    void addNav(LinearLayout nav, String label, String page) {
        Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setTextColor(gold); b.setBackgroundColor(navy);
        b.setOnClickListener(v -> { if(page.equals("home")) showHome(); else showList(page); });
        nav.addView(b, new LinearLayout.LayoutParams(0,-2,1));
    }
    void showHome() {
        base("إدارة مكتب المحاماة");
        TextView intro = text("إدارة أعمالك القانونية بسهولة، حتى دون اتصال بالإنترنت.",16,navy);
        body.addView(intro);
        addStat("القضايا المسجلة", db.count("cases"));
        addStat("الموكلون", db.count("clients"));
        addStat("الجلسات", db.count("sessions"));
        addStat("المهام", db.count("tasks"));
        Button backup = new Button(this); backup.setText("ملاحظة النسخ الاحتياطي"); backup.setOnClickListener(v ->
            new AlertDialog.Builder(this).setMessage("البيانات محفوظة محلياً على الهاتف. أضفنا التصدير/الاستيراد إلى خطة التحديث التالية.").setPositiveButton("حسناً",null).show());
        body.addView(backup);
    }
    void addStat(String label, int n) {
        TextView t = text(label + " :  " + n,18,navy); t.setBackgroundColor(Color.WHITE); t.setElevation(2);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(4,8,4,8); body.addView(t,p);
    }
    void showList(String table) {
        current = table; String title = table.equals("cases")?"ملفات القضايا":table.equals("clients")?"الموكلون":table.equals("sessions")?"الجلسات":"المهام";
        base(title);
        Button add = new Button(this); add.setText("+ إضافة جديد"); add.setOnClickListener(v -> addRecord(table)); body.addView(add);
        Cursor c = db.all(table);
        while(c.moveToNext()) {
            StringBuilder line = new StringBuilder();
            for(int i=1;i<c.getColumnCount();i++) {
                String val = c.getString(i); if(val!=null && !val.trim().isEmpty()) { if(line.length()>0) line.append("  •  "); line.append(val); }
            }
            TextView item = text(line.toString(),15,navy); item.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(2,6,2,6); body.addView(item,p);
        }
        c.close();
    }
    void addRecord(String table) {
        String[] labels, keys;
        if(table.equals("cases")) { labels=new String[]{"رقم القضية","المحكمة","نوع القضية","الخصوم","تاريخ الجلسة القادمة","ملاحظات"}; keys=new String[]{"number","court","type","parties","next_date","notes"}; }
        else if(table.equals("clients")) { labels=new String[]{"اسم الموكل","رقم الهاتف","العنوان","ملاحظات"}; keys=new String[]{"name","phone","address","notes"}; }
        else if(table.equals("sessions")) { labels=new String[]{"رقم القضية","المحكمة","تاريخ الجلسة","القرار"}; keys=new String[]{"case_number","court","date","decision"}; }
        else { labels=new String[]{"عنوان المهمة","تاريخ الاستحقاق"}; keys=new String[]{"title","due_date"}; }
        LinearLayout form = new LinearLayout(this); form.setOrientation(1); EditText[] inputs = new EditText[labels.length];
        for(int i=0;i<labels.length;i++){ inputs[i]=new EditText(this); inputs[i].setSingleLine(false); inputs[i].setHint(labels[i]); form.addView(inputs[i]); }
        new AlertDialog.Builder(this).setTitle("إضافة سجل").setView(form).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
            ContentValues cv=new ContentValues(); for(int i=0;i<labels.length;i++) cv.put(keys[i],inputs[i].getText().toString().trim());
            db.add(table,cv); showList(table);
        }).show();
    }
}
